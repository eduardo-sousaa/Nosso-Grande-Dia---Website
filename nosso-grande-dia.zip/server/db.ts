import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  Usuario,
  Casamento,
  CasamentoUsuario,
  Paleta,
  Cor,
  Tarefa,
  CategoriaTarefa,
  Decisao,
  Convidado,
  GrupoConvidado,
  ParticipanteCerimonia,
  Album,
  Imagem,
  CategoriaFinanceira,
  Fornecedor,
  Despesa,
  EventoCronograma,
  CategoriaDocumento,
  Documento,
  DiarioMemoria,
  AlertaCalculado,
  ResumoDashboard
} from '../src/types/index';

interface DatabaseSchema {
  usuarios: Usuario[];
  casamentos: Casamento[];
  casamento_usuarios: CasamentoUsuario[];
  paletas: Paleta[];
  cores: Cor[];
  categorias_tarefa: CategoriaTarefa[];
  tarefas: Tarefa[];
  decisoes: Decisao[];
  grupos_convidados: GrupoConvidado[];
  convidados: Convidado[];
  participantes_cerimonia: ParticipanteCerimonia[];
  albuns: Album[];
  imagens: Imagem[];
  categorias_financeiras: CategoriaFinanceira[];
  fornecedores: Fornecedor[];
  despesas: Despesa[];
  eventos_cronograma: EventoCronograma[];
  categorias_documento: CategoriaDocumento[];
  documentos: Documento[];
  diario: DiarioMemoria[];
}

const DB_FILE = path.join(process.cwd(), 'data_db.json');

class DatabaseStore {
  private data: DatabaseSchema = {
    usuarios: [],
    casamentos: [],
    casamento_usuarios: [],
    paletas: [],
    cores: [],
    categorias_tarefa: [],
    tarefas: [],
    decisoes: [],
    grupos_convidados: [],
    convidados: [],
    participantes_cerimonia: [],
    albuns: [],
    imagens: [],
    categorias_financeiras: [],
    fornecedores: [],
    despesas: [],
    eventos_cronograma: [],
    categorias_documento: [],
    documentos: [],
    diario: []
  };

  constructor() {
    this.init();
  }

  private init() {
    if (fs.existsSync(DB_FILE)) {
      try {
        const fileData = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(fileData);
        this.ensureArrayKeys();
        return;
      } catch (err) {
        console.error('Error loading database file, re-seeding default data:', err);
      }
    }
    this.seedDefaultData();
    this.save();
  }

  private ensureArrayKeys() {
    const keys: (keyof DatabaseSchema)[] = [
      'usuarios', 'casamentos', 'casamento_usuarios', 'paletas', 'cores',
      'categorias_tarefa', 'tarefas', 'decisoes', 'grupos_convidados',
      'convidados', 'participantes_cerimonia', 'albuns', 'imagens',
      'categorias_financeiras', 'fornecedores', 'despesas', 'eventos_cronograma',
      'categorias_documento', 'documentos', 'diario'
    ];
    for (const key of keys) {
      if (!Array.isArray(this.data[key])) {
        (this.data as any)[key] = [];
      }
    }
  }

  public save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save database file:', err);
    }
  }

  private seedDefaultData() {
    const now = new Date().toISOString();

    // 1. Initial Users (Noivo & Noiva without mock photos or fixed names)
    const userNoivo: Usuario = {
      id: 'usr_noivo_1',
      nome: 'Noivo',
      email: 'noivo@nossograndedia.com',
      foto: null,
      tipo: 'NOIVO',
      criado_em: now,
      atualizado_em: now
    };

    const userNoiva: Usuario = {
      id: 'usr_noiva_1',
      nome: 'Noiva',
      email: 'noiva@nossograndedia.com',
      foto: null,
      tipo: 'NOIVA',
      criado_em: now,
      atualizado_em: now
    };

    this.data.usuarios = [userNoivo, userNoiva];

    // 2. Initial Wedding (Casamento) - blank initial state
    const casamId = 'casam_1';
    const defaultCasamento: Casamento = {
      id: casamId,
      nome: 'Nosso Casamento',
      nome_noivo: null,
      nome_noiva: null,
      data_casamento: null,
      horario: null,
      local: null,
      endereco: null,
      cidade: null,
      estado: null,
      frase: null,
      imagem_capa: null,
      configurado: false,
      criado_em: now,
      atualizado_em: now
    };

    this.data.casamentos = [defaultCasamento];

    this.data.casamento_usuarios = [
      { casamento_id: casamId, usuario_id: userNoivo.id, tipo: 'NOIVO' },
      { casamento_id: casamId, usuario_id: userNoiva.id, tipo: 'NOIVA' }
    ];

    // 3. Palette & Colors (Default palette categories)
    const paletaId = 'paleta_1';
    this.data.paletas = [{
      id: paletaId,
      casamento_id: casamId,
      nome: 'Paleta Visual',
      criada_em: now,
      cores: []
    }];

    this.data.cores = [
      { id: 'cor_1', paleta_id: paletaId, nome: 'Vermelho Marsala', codigo_hex: '#800020', ordem: 1, tipo: 'PRIMARIA' },
      { id: 'cor_2', paleta_id: paletaId, nome: 'Verde Oliva', codigo_hex: '#556B2F', ordem: 2, tipo: 'SECUNDARIA' },
      { id: 'cor_3', paleta_id: paletaId, nome: 'Creme Romance', codigo_hex: '#FAF6F0', ordem: 3, tipo: 'FUNDO' },
      { id: 'cor_4', paleta_id: paletaId, nome: 'Dourado Suave', codigo_hex: '#D4AF37', ordem: 4, tipo: 'DESTAQUE' }
    ];

    // 4. Default Task Categories (Empty tasks array)
    const catTaskNames = [
      'Cerimônia', 'Festa', 'Noivos', 'Convidados', 'Decoração',
      'Fornecedores', 'Documentação', 'Lua de mel', 'Financeiro', 'Outros'
    ];
    this.data.categorias_tarefa = catTaskNames.map((nome, idx) => ({
      id: `cat_tar_${idx + 1}`,
      casamento_id: casamId,
      nome,
      ativa: true
    }));

    this.data.tarefas = [];

    // 5. Decisions (Empty)
    this.data.decisoes = [];

    // 6. Guest Groups (Empty guests array)
    const catGuestGroups = [
      'Família do noivo', 'Família da noiva', 'Amigos do noivo',
      'Amigos da noiva', 'Trabalho', 'Outros'
    ];
    this.data.grupos_convidados = catGuestGroups.map((nome, idx) => ({
      id: `grp_guest_${idx + 1}`,
      casamento_id: casamId,
      nome
    }));

    this.data.convidados = [];

    // 7. Ceremony Participants (Empty)
    this.data.participantes_cerimonia = [];

    // 8. Idea Albums (Empty)
    this.data.albuns = [];
    this.data.imagens = [];

    // 9. Finance Categories (Empty suppliers & expenses)
    const finCats = ['Local & Buffet', 'Decoração & Flores', 'Foto & Vídeo', 'Música & Iluminação', 'Vestuário & Beleza', 'Assessoria'];
    this.data.categorias_financeiras = finCats.map((nome, idx) => ({
      id: `cat_fin_${idx + 1}`,
      casamento_id: casamId,
      nome
    }));

    this.data.fornecedores = [];
    this.data.despesas = [];

    // 10. Cronograma (Timeline - Empty)
    this.data.eventos_cronograma = [];

    // 11. Document Categories & Documents (Empty documents)
    const docCats = ['Contratos', 'Financeiro', 'Cerimônia', 'Fornecedores', 'Viagem', 'Outros'];
    this.data.categorias_documento = docCats.map((nome, idx) => ({
      id: `cat_doc_${idx + 1}`,
      casamento_id: casamId,
      nome
    }));

    this.data.documentos = [];

    // 12. Journal (Empty)
    this.data.diario = [];
  }

  // Getters & Database Query Helper methods
  public getStore(): DatabaseSchema {
    return this.data;
  }

  public getCasamento(id?: string): Casamento | null {
    if (!this.data.casamentos.length) return null;
    if (id) {
      return this.data.casamentos.find(c => c.id === id) || null;
    }
    return this.data.casamentos[0] || null;
  }

  public updateCasamento(id: string, updates: Partial<Casamento>): Casamento | null {
    const idx = this.data.casamentos.findIndex(c => c.id === id);
    if (idx === -1) return null;
    this.data.casamentos[idx] = {
      ...this.data.casamentos[idx],
      ...updates,
      atualizado_em: new Date().toISOString()
    };
    this.save();
    return this.data.casamentos[idx];
  }

  public getUsuarioById(id: string): Usuario | null {
    return this.data.usuarios.find(u => u.id === id) || null;
  }

  public registerUsuario(data: { email: string; senha?: string; nome_noivo: string; nome_noiva: string }): { user: Usuario; casamento: Casamento } {
    const now = new Date().toISOString();
    const existing = this.data.usuarios.find(u => u.email.toLowerCase() === data.email.toLowerCase());
    if (existing) {
      throw new Error('Já existe uma conta cadastrada com este e-mail.');
    }

    const coupleName = `${data.nome_noivo} & ${data.nome_noiva}`;
    const newUser: Usuario = {
      id: `usr_${Date.now()}`,
      nome: coupleName,
      nome_noivo: data.nome_noivo,
      nome_noiva: data.nome_noiva,
      email: data.email.toLowerCase(),
      senha: data.senha || '123456',
      foto: null,
      criado_em: now,
      atualizado_em: now
    };

    this.data.usuarios.push(newUser);

    // Update or create casamento
    let casamento = this.getCasamento();
    if (!casamento) {
      casamento = {
        id: `casam_${Date.now()}`,
        nome: `Casamento ${coupleName}`,
        nome_noivo: data.nome_noivo,
        nome_noiva: data.nome_noiva,
        data_casamento: null,
        horario: null,
        local: null,
        endereco: null,
        cidade: null,
        estado: null,
        frase: null,
        imagem_capa: null,
        configurado: false,
        criado_em: now,
        atualizado_em: now
      };
      this.data.casamentos.push(casamento);
    } else {
      casamento.nome = `Casamento ${coupleName}`;
      casamento.nome_noivo = data.nome_noivo;
      casamento.nome_noiva = data.nome_noiva;
      casamento.atualizado_em = now;
    }

    this.save();
    return { user: newUser, casamento };
  }

  public loginUsuario(email: string, senha?: string): { user: Usuario; casamento: Casamento } {
    const user = this.data.usuarios.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      throw new Error('E-mail ou senha incorretos.');
    }

    if (senha && user.senha && user.senha !== senha) {
      throw new Error('E-mail ou senha incorretos.');
    }

    let casamento = this.getCasamento();
    if (!casamento) {
      const now = new Date().toISOString();
      casamento = {
        id: `casam_${Date.now()}`,
        nome: `Casamento ${user.nome}`,
        nome_noivo: user.nome_noivo || null,
        nome_noiva: user.nome_noiva || null,
        data_casamento: null,
        horario: null,
        local: null,
        endereco: null,
        cidade: null,
        estado: null,
        frase: null,
        imagem_capa: null,
        configurado: false,
        criado_em: now,
        atualizado_em: now
      };
      this.data.casamentos.push(casamento);
      this.save();
    }

    return { user, casamento };
  }

  public updateUsuario(id: string, updates: Partial<Usuario>): Usuario | null {
    const idx = this.data.usuarios.findIndex(u => u.id === id);
    if (idx === -1) return null;

    const current = this.data.usuarios[idx];
    const newGroom = updates.nome_noivo !== undefined ? updates.nome_noivo : current.nome_noivo;
    const newBride = updates.nome_noiva !== undefined ? updates.nome_noiva : current.nome_noiva;
    
    let computedName = updates.nome;
    if (newGroom && newBride && (!computedName || updates.nome_noivo || updates.nome_noiva)) {
      computedName = `${newGroom} & ${newBride}`;
    }

    this.data.usuarios[idx] = {
      ...current,
      ...updates,
      ...(computedName && { nome: computedName }),
      atualizado_em: new Date().toISOString()
    };

    // Update wedding record if groom or bride names changed
    const casamento = this.getCasamento();
    if (casamento) {
      if (newGroom !== undefined) casamento.nome_noivo = newGroom;
      if (newBride !== undefined) casamento.nome_noiva = newBride;
      if (computedName) casamento.nome = `Casamento ${computedName}`;
      casamento.atualizado_em = new Date().toISOString();
    }

    this.save();
    return this.data.usuarios[idx];
  }

  public getDashboardResumo(casamentoId: string): ResumoDashboard {
    const casamento = this.getCasamento(casamentoId);

    // Calculate countdown
    let diasRestantes: number | null = null;
    if (casamento && casamento.data_casamento) {
      const targetDate = new Date(casamento.data_casamento + 'T00:00:00');
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const diffTime = targetDate.getTime() - today.getTime();
      diasRestantes = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    // Tasks calculation
    const tarefasCasamento = this.data.tarefas.filter(t => t.casamento_id === casamentoId);
    const totalTarefas = tarefasCasamento.length;
    const concluidas = tarefasCasamento.filter(t => t.status === 'CONCLUIDA').length;
    const progressoPlanejamento = totalTarefas > 0 ? Math.round((concluidas / totalTarefas) * 100) : 0;

    const tarefasPendentes = tarefasCasamento.filter(t => t.status === 'PENDENTE' || t.status === 'EM_ANDAMENTO').length;
    
    // Overdue tasks
    const todayStr = new Date().toISOString().split('T')[0];
    const tarefasAtrasadas = tarefasCasamento.filter(t => 
      (t.status === 'PENDENTE' || t.status === 'EM_ANDAMENTO') && 
      t.prazo && 
      t.prazo < todayStr
    ).length;

    // Decisions
    const decisoesCasamento = this.data.decisoes.filter(d => d.casamento_id === casamentoId);
    const decisoesPendentes = decisoesCasamento.filter(d => d.status === 'PENDENTE').length;
    const decisoesConcluidas = decisoesCasamento.filter(d => d.status === 'DECIDIDA').length;

    // Guests & Ceremony Participants
    const convidados = this.data.convidados.filter(g => g.casamento_id === casamentoId);
    const totalConvidados = convidados.reduce((acc, curr) => acc + 1 + (curr.acompanhante || 0), 0);

    const participantes = this.data.participantes_cerimonia.filter(p => p.casamento_id === casamentoId);
    const totalPadrinhosMadrinhas = participantes.length;

    // Financial calculations
    const despesas = this.data.despesas.filter(d => d.casamento_id === casamentoId && d.status !== 'CANCELADO');
    const total_planejado = despesas.reduce((acc, d) => acc + (d.valor_previsto || 0), 0);
    const total_contratado = despesas.reduce((acc, d) => acc + (d.valor_final || 0), 0);
    const total_pago = despesas.reduce((acc, d) => acc + (d.valor_pago || 0), 0);
    const total_restante = Math.max(0, total_contratado - total_pago);

    // Upcoming Events
    const proximosEventos = this.data.eventos_cronograma
      .filter(e => e.casamento_id === casamentoId)
      .sort((a, b) => a.data_inicio.localeCompare(b.data_inicio))
      .slice(0, 5);

    // Calculate smart alerts
    const alertas: AlertaCalculado[] = [];

    if (tarefasAtrasadas > 0) {
      alertas.push({
        id: 'alt_tar_atrasada',
        tipo: 'TAREFA_ATRASADA',
        titulo: 'Tarefas em atraso',
        mensagem: `Você possui ${tarefasAtrasadas} tarefa(s) pendente(s) com prazo ultrapassado.`,
        nivel: 'URGENTE',
        link: '/planejamento/tarefas'
      });
    }

    if (decisoesPendentes > 0) {
      alertas.push({
        id: 'alt_dec_pendente',
        tipo: 'TAREFA_VENCENDO',
        titulo: 'Decisões a tomar',
        mensagem: `Existem ${decisoesPendentes} decisão(ões) pendente(s) que precisam da atenção do casal.`,
        nivel: 'ALERTA',
        link: '/planejamento/decisoes'
      });
    }

    // Unconfirmed guests check
    const aguardandoRSVP = convidados.filter(g => g.confirmacao === 'AGUARDANDO').length;
    if (aguardandoRSVP > 0) {
      alertas.push({
        id: 'alt_rsvp_pendente',
        tipo: 'CONVIDADO_PENDENTE',
        titulo: 'Confirmações de presença',
        mensagem: `${aguardandoRSVP} convidado(s) ainda não responderam ao convite.`,
        nivel: 'INFO',
        link: '/convidados'
      });
    }

    // Payments due soon
    const nextWeekStr = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const pagamentosProximos = despesas.filter(d => 
      d.status !== 'PAGO' && 
      d.data_vencimento && 
      d.data_vencimento <= nextWeekStr
    );
    if (pagamentosProximos.length > 0) {
      alertas.push({
        id: 'alt_pag_proximo',
        tipo: 'PAGAMENTO_PROXIMO',
        titulo: 'Pagamento próximo do vencimento',
        mensagem: `${pagamentosProximos.length} parcela(s) financeira(s) vencem nos próximos 7 dias.`,
        nivel: 'ALERTA',
        link: '/orcamento'
      });
    }

    return {
      casamento,
      dias_restantes: diasRestantes,
      progresso_planejamento: progressoPlanejamento,
      tarefas_pendentes: tarefasPendentes,
      tarefas_atrasadas: tarefasAtrasadas,
      decisoes_pendentes: decisoesPendentes,
      decisoes_concluidas: decisoesConcluidas,
      total_convidados: totalConvidados,
      total_padrinhos_madrinhas: totalPadrinhosMadrinhas,
      resumo_financeiro: {
        total_planejado,
        total_contratado,
        total_pago,
        total_restante
      },
      proximos_eventos: proximosEventos,
      alertas
    };
  }
}

export const dbStore = new DatabaseStore();
